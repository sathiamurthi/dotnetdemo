# cqrs-mediatr-aspnet-core
## https://code-maze.com/cqrs-mediatr-in-aspnet-core/
This repo contains the source code for the "CQRS and MediatR with ASP.NET Core" article on Code Maze
